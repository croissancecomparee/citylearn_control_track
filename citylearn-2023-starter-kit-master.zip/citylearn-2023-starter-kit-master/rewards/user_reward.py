from rewards.comfort_reward import ComfortRewardFunction

###################################################################
#####                Specify your reward here                 #####
###################################################################

SubmissionReward = ComfortRewardFunction