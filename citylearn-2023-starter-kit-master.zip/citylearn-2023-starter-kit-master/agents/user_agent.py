from agents.rbc_agent import BasicRBCAgent

###################################################################
#####                Specify your agent here                  #####
###################################################################

SubmissionAgent = BasicRBCAgent
